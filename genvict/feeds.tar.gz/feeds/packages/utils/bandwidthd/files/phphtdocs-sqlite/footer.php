<?php
echo("Page load completed in ". (time() - $starttime) ." seconds"); 
?>
