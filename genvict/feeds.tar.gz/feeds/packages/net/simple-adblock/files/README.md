# README

README has been moved to [https://docs.openwrt.melmac.net/simple-adblock/](https://docs.openwrt.melmac.net/simple-adblock/).
