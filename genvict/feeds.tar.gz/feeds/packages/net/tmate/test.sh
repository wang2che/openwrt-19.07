#!/bin/sh

tmate -V | grep "$PKG_VERSION"
