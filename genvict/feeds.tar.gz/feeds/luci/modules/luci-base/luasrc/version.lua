-- Licensed to the public under the Apache License 2.0.

module "luci.version"

distname    = "Host System"
distversion = "SDK"

luciname    = "LuCI"
luciversion = "SVN"
